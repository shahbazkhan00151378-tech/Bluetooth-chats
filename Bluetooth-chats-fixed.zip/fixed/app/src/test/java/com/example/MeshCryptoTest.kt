package com.example

import com.example.crypto.MeshCrypto
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MeshCryptoTest {
    private fun newCrypto() = MeshCrypto(null, null) { _, _ -> }

    @Test
    fun bothSidesDeriveSameKeyAndDecrypt() {
        val a = newCrypto()
        val b = newCrypto()
        val keyA = a.sharedKey(b.publicKeyBytes)
        val keyB = b.sharedKey(a.publicKeyBytes)
        assertArrayEquals(keyA, keyB)

        val aad = "msg1|NA".toByteArray()
        val cipher = a.encrypt(keyA, "Hello Bluetooth".toByteArray(), aad)
        assertEquals("Hello Bluetooth", String(b.decrypt(keyB, cipher, aad)!!))
    }

    @Test
    fun tamperedOrWrongAadFails() {
        val a = newCrypto()
        val b = newCrypto()
        val key = a.sharedKey(b.publicKeyBytes)
        val cipher = a.encrypt(key, "secret".toByteArray(), "id1".toByteArray())

        assertNull(b.decrypt(key, cipher, "id2".toByteArray()))          // wrong AAD
        val bad = cipher.copyOf().also { it[it.size - 1] = (it[it.size - 1].toInt() xor 1).toByte() }
        assertNull(b.decrypt(key, bad, "id1".toByteArray()))              // flipped bit
    }

    @Test
    fun eavesdropperKeyCannotDecrypt() {
        val a = newCrypto(); val b = newCrypto(); val eve = newCrypto()
        val cipher = a.encrypt(a.sharedKey(b.publicKeyBytes), "private".toByteArray(), ByteArray(0))
        assertNull(eve.decrypt(eve.sharedKey(a.publicKeyBytes), cipher, ByteArray(0)))
    }
}

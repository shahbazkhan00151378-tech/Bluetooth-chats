package com.example.ble

import java.util.UUID

object BleConstants {
    // Dedicated MeshLink 128-bit Service UUID (using 16-bit alias 0xFD42 base)
    val SERVICE_UUID: UUID = UUID.fromString("0000FD42-0000-1000-8000-00805F9B34FB")

    // Characteristic for transmitting/receiving text message payloads (Read/Write)
    val CHAR_MESSAGE_UUID: UUID = UUID.fromString("0000FD43-0000-1000-8000-00805F9B34FB")

    // Characteristic for delivery acknowledgement and status verification
    val CHAR_ACK_UUID: UUID = UUID.fromString("0000FD44-0000-1000-8000-00805F9B34FB")

    // Characteristic exposing this phone's PUBLIC encryption key (read-only) for key agreement
    val CHAR_PUBKEY_UUID: UUID = UUID.fromString("0000FD45-0000-1000-8000-00805F9B34FB")

    // Standard BLE unfragmented payload size limit (Default ATT MTU 23 - 3 bytes header = 20 bytes)
    const val DEFAULT_MAX_PAYLOAD_BYTES = 20

    // Expanded MTU target for negotiated BLE connections
    const val TARGET_NEGOTIATED_MTU = 512

    // Standard Client Characteristic Configuration Descriptor (enables notifications)
    val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")

    // Manufacturer-data company id used in our advertisement (0xFFFF = reserved for testing)
    const val MANUFACTURER_ID = 0xFFFF

    // Wire protocol: "ML1|M|<msgId>|<senderId>|<senderName>|<text>" and ACK "ML1|A|<msgId>"
    const val PROTO_PREFIX = "ML1|"

    // Mesh relay: how many hops a flooded frame may travel, and how long a peer sighting stays valid
    const val DEFAULT_TTL = 3
    const val PEER_FRESH_MS = 120_000L

    // How long the sender waits for the receiver's ACK before leaving the message as "Sent"
    const val ACK_TIMEOUT_MS = 6_000L

    // Auto scan timeout in milliseconds (20 seconds)
    const val SCAN_TIMEOUT_MS = 20_000L
}

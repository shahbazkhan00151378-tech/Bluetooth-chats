package com.example.crypto

import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * End-to-end encryption for MeshLink direct messages (pure JVM, no Android classes -> unit-testable).
 *
 *  - Identity: one EC P-256 key pair per install.
 *  - Key agreement: ECDH(my private, peer public) -> HKDF-SHA256 -> 256-bit AES key.
 *  - Message: AES-256-GCM, random 96-bit IV, sender/message id bound as authenticated data (AAD).
 *
 * NOTE: this is a prototype design and has NOT had an independent security review.
 */
class MeshCrypto(
    storedPrivatePkcs8: ByteArray?,
    storedPublicX509: ByteArray?,
    persist: (privatePkcs8: ByteArray, publicX509: ByteArray) -> Unit
) {
    private val privateKey: PrivateKey
    /** X.509 encoded public key (shared with peers). */
    val publicKeyBytes: ByteArray

    init {
        val kf = KeyFactory.getInstance("EC")
        if (storedPrivatePkcs8 != null && storedPublicX509 != null) {
            privateKey = kf.generatePrivate(PKCS8EncodedKeySpec(storedPrivatePkcs8))
            publicKeyBytes = storedPublicX509
        } else {
            val gen = KeyPairGenerator.getInstance("EC")
            gen.initialize(ECGenParameterSpec("secp256r1"))
            val pair = gen.generateKeyPair()
            privateKey = pair.private
            publicKeyBytes = pair.public.encoded
            persist(pair.private.encoded, pair.public.encoded)
        }
    }

    /** Short human-comparable fingerprint of a public key (verify out-of-band to defeat first-contact MITM). */
    fun fingerprint(publicX509: ByteArray = publicKeyBytes): String =
        MessageDigest.getInstance("SHA-256").digest(publicX509)
            .take(8).joinToString("") { "%02X".format(it) }
            .chunked(4).joinToString("-")

    /** Derives the 32-byte AES key shared with [peerPublicX509]. Same result on both phones. */
    fun sharedKey(peerPublicX509: ByteArray): ByteArray {
        val peerPublic: PublicKey = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(peerPublicX509))
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(privateKey)
        ka.doPhase(peerPublic, true)
        val secret = ka.generateSecret()

        // Bind the key to both identities, order-independent so both sides derive the same key
        val (a, b) = if (compare(publicKeyBytes, peerPublicX509) <= 0) publicKeyBytes to peerPublicX509
                     else peerPublicX509 to publicKeyBytes
        val info = "MeshLink-v1".toByteArray(Charsets.UTF_8) + a + b

        val prk = hmac(ByteArray(32), secret)               // HKDF-Extract
        return hmac(prk, info + byteArrayOf(0x01))          // HKDF-Expand (one block = 32 bytes)
    }

    /** Returns iv(12) || ciphertext+tag. */
    fun encrypt(key: ByteArray, plaintext: ByteArray, aad: ByteArray): ByteArray {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        c.updateAAD(aad)
        return iv + c.doFinal(plaintext)
    }

    /** Returns the plaintext, or null if the data was tampered with / the key or AAD is wrong. */
    fun decrypt(key: ByteArray, data: ByteArray, aad: ByteArray): ByteArray? {
        if (data.size < 12 + 16) return null
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, data.copyOfRange(0, 12)))
            c.updateAAD(aad)
            c.doFinal(data, 12, data.size - 12)
        } catch (e: Exception) {
            null
        }
    }

    private fun hmac(key: ByteArray, data: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(data)
    }

    private fun compare(x: ByteArray, y: ByteArray): Int {
        val n = minOf(x.size, y.size)
        for (i in 0 until n) {
            val d = (x[i].toInt() and 0xFF) - (y[i].toInt() and 0xFF)
            if (d != 0) return d
        }
        return x.size - y.size
    }
}

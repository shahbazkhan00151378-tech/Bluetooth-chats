package com.example.ble

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import android.util.Base64
import com.example.crypto.MeshCrypto
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class BleMeshManager(private val context: Context) {

    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanner: BluetoothLeScanner? = null
    private var gattServer: BluetoothGattServer? = null
    private var activeClientGatt: BluetoothGatt? = null
    private var connectingDeviceAddress: String? = null

    // Handlers on Main Looper
    private val mainHandler: Handler = Handler(Looper.getMainLooper())
    private val scanTimeoutRunnable = Runnable {
        if (_isScanning.value) {
            val peerCount = _discoveredPeers.value.size
            _statusLog.value = "Scan finished (timed out after 20s). Discovered $peerCount device(s)."
            stopScanning()
        }
    }

    private val connectionTimeoutRunnable = Runnable {
        // FIX: also covers a hang after connect (service discovery / write never completes)
        val targetAddr = connectingDeviceAddress ?: activeClientGatt?.device?.address
        if (targetAddr != null && pendingOutgoingMessageId != null) {
            _statusLog.value = "Transfer with $targetAddr timed out after 15s"
            markPendingMessageFailed("Connection timed out")
            disconnectPeer(targetAddr)
        }
    }

    // State Flows
    private val _hardwareState = MutableStateFlow(BleHardwareState.CHECKING)
    val hardwareState: StateFlow<BleHardwareState> = _hardwareState.asStateFlow()

    private val _isAdvertising = MutableStateFlow(false)
    val isAdvertising: StateFlow<Boolean> = _isAdvertising.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _discoveredPeers = MutableStateFlow<List<DiscoveredPeerDevice>>(emptyList())
    val discoveredPeers: StateFlow<List<DiscoveredPeerDevice>> = _discoveredPeers.asStateFlow()

    private val _connectedPeerAddress = MutableStateFlow<String?>(null)
    val connectedPeerAddress: StateFlow<String?> = _connectedPeerAddress.asStateFlow()

    private val _peerConnectionStates = MutableStateFlow<Map<String, PeerConnectionInfo>>(emptyMap())
    val peerConnectionStates: StateFlow<Map<String, PeerConnectionInfo>> = _peerConnectionStates.asStateFlow()

    private val _nativeMessages = MutableStateFlow<List<NativeBleMessage>>(emptyList())
    val nativeMessages: StateFlow<List<NativeBleMessage>> = _nativeMessages.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val _statusLog = MutableStateFlow<String?>("BLE subsystem initialized")
    val statusLog: StateFlow<String?> = _statusLog.asStateFlow()

    // ---- Stable identity (survives restarts; BLE MAC addresses do not) ----
    private val prefs = context.getSharedPreferences("meshlink_identity", Context.MODE_PRIVATE)
    val localNodeId: String = prefs.getString("node_id", null) ?: run {
        val id = "N" + UUID.randomUUID().toString().replace("-", "").take(7).uppercase()
        prefs.edit().putString("node_id", id).apply()
        id
    }
    // Short name (<=15 bytes) so it fits in the scan response next to the id
    val localNodeName: String = (prefs.getString("node_name", null) ?: Build.MODEL ?: "MeshLink")
        .toByteArray(Charsets.UTF_8).let { String(it.copyOf(minOf(it.size, 15)), Charsets.UTF_8) }
        .replace("|", " ").ifBlank { "MeshLink" }

    // ---- End-to-end encryption (ECDH + AES-GCM) ----
    private val keyPrefs = context.getSharedPreferences("meshlink_keys", Context.MODE_PRIVATE)
    private val crypto: MeshCrypto = MeshCrypto(
        keyPrefs.getString("my_private", null)?.let { Base64.decode(it, Base64.NO_WRAP) },
        keyPrefs.getString("my_public", null)?.let { Base64.decode(it, Base64.NO_WRAP) }
    ) { priv, pub ->
        keyPrefs.edit()
            .putString("my_private", Base64.encodeToString(priv, Base64.NO_WRAP))
            .putString("my_public", Base64.encodeToString(pub, Base64.NO_WRAP))
            .apply()
    }
    /** Compare this value with the one shown on the other phone to rule out a man-in-the-middle. */
    val myKeyFingerprint: String get() = crypto.fingerprint()
    @Volatile private var pendingSessionKey: ByteArray? = null

    /**
     * Trust-on-first-use: the first key seen for a node id is remembered; a different key later is rejected
     * (that is either a reinstall or an attacker pretending to be that node).
     */
    private fun pinOrCheckKey(nodeId: String, pub: ByteArray): Boolean {
        val name = "peer_$nodeId"
        val b64 = Base64.encodeToString(pub, Base64.NO_WRAP)
        val known = keyPrefs.getString(name, null)
        if (known == null) { keyPrefs.edit().putString(name, b64).apply(); return true }
        return known == b64
    }
    /** After a peer reinstalls the app, call this so its new key is accepted again. */
    fun forgetPeerKey(nodeId: String) { keyPrefs.edit().remove("peer_$nodeId").apply() }

    @Volatile private var awaitingAckForId: String? = null
    private val ackTimeoutRunnable = Runnable {
        val id = awaitingAckForId
        if (id != null) {
            _statusLog.value = "No ACK from peer for $id (message stays 'Sent')"
            _nativeMessages.update { list ->
                list.map { if (it.id == id) it.copy(deliveryStatus = "Sent (no ACK from peer)") else it }
            }
            finishPending(activeClientGatt)
        }
    }

    @Volatile private var pendingOutgoingPayload: String? = null
    @Volatile private var pendingOutgoingMessageId: String? = null

    // FIX: outgoing queue. Before, a 2nd send overwrote the 1st pending message (stuck forever)
    // and closed the in-flight GATT. Now messages are sent one after another.
    private data class QueuedSend(
        val device: BluetoothDevice,
        val text: String,
        val id: String,
        val frame: String? = null,        // null = normal direct "M" frame built at write time
        val expectAck: Boolean = true,    // direct messages wait for the peer's ACK
        val broadcast: Boolean = false,   // group/relay flood: one id sent to several peers
        val notify: Boolean = true,       // false for frames we only forward for others
        val routeDest: String? = null     // set when sent along a learned route (unicast) instead of flooding
    )
    @Volatile private var pendingItem: QueuedSend? = null

    // ---- Routing table + link health (self-healing) ----
    private data class Route(val nextHopNodeId: String, val learnedMs: Long)
    private val routes = java.util.concurrent.ConcurrentHashMap<String, Route>()
    private data class LinkHealth(val failures: Int, val lastFailMs: Long)
    private val linkHealth = java.util.concurrent.ConcurrentHashMap<String, LinkHealth>()

    private fun isLinkBroken(nodeId: String?): Boolean {
        if (nodeId == null) return false
        val h = linkHealth[nodeId] ?: return false
        return h.failures >= 3 && System.currentTimeMillis() - h.lastFailMs < 60_000L
    }
    private fun recordLinkFailure(nodeId: String?) {
        if (nodeId == null) return
        linkHealth.merge(nodeId, LinkHealth(1, System.currentTimeMillis())) { old, _ ->
            LinkHealth(old.failures + 1, System.currentTimeMillis())
        }
    }
    private fun recordLinkSuccess(nodeId: String?) {
        if (nodeId != null) linkHealth.remove(nodeId)
    }
    private fun learnRoute(destNodeId: String, viaNodeId: String) {
        if (destNodeId == localNodeId || viaNodeId == localNodeId) return
        routes[destNodeId] = Route(viaNodeId, System.currentTimeMillis())
    }
    private fun nodeIdOfAddress(address: String?): String? =
        _discoveredPeers.value.firstOrNull { it.address == address }?.nodeId

    /** Read-only view of the learned routes for the UI: destination -> next hop node id. */
    fun routeSnapshot(): Map<String, String> = routes.mapValues { it.value.nextHopNodeId }
    @Volatile private var pendingFrame: String? = null
    @Volatile private var pendingExpectAck: Boolean = true
    @Volatile private var pendingBroadcast: Boolean = false
    @Volatile private var pendingNotify: Boolean = true
    private val broadcastSucceeded = java.util.Collections.synchronizedSet(HashSet<String>())
    private val sendQueue = java.util.ArrayDeque<QueuedSend>()

    // FIX: buffer for BLE "long writes" (messages > MTU-3 arrive in several prepared-write chunks)
    private val preparedWriteBuffers = java.util.concurrent.ConcurrentHashMap<String, java.io.ByteArrayOutputStream>()
    var persistenceListener: BleMessagePersistenceListener? = null

    fun updatePeerConnectionState(address: String, name: String?, state: PeerConnectionState) {
        _peerConnectionStates.update { old ->
            val current = old.toMutableMap()
            current[address.uppercase()] = PeerConnectionInfo(
                state = state,
                peerAddress = address,
                peerName = name ?: current[address.uppercase()]?.peerName,
                lastStateChangeMs = System.currentTimeMillis()
            )
            current
        }
    }

    fun getPeerConnectionState(address: String?): PeerConnectionState {
        if (address == null) return PeerConnectionState.DISCONNECTED
        return _peerConnectionStates.value[address.uppercase()]?.state ?: PeerConnectionState.DISCONNECTED
    }

    init {
        try {
            refreshHardwareState()
        } catch (e: Exception) {
            _hardwareState.value = BleHardwareState.HARDWARE_UNAVAILABLE
            _statusLog.value = "Hardware initialization check caught: ${e.message}"
        }
    }

    fun isBleSupported(): Boolean {
        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)
    }

    fun isBluetoothEnabled(): Boolean {
        return try {
            bluetoothAdapter?.isEnabled == true
        } catch (e: Exception) {
            false
        }
    }

    fun hasRequiredPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val scanGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED
            val advGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_ADVERTISE
            ) == PackageManager.PERMISSION_GRANTED
            val connGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
            scanGranted && advGranted && connGranted
        } else {
            val fineGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            val coarseGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            fineGranted || coarseGranted
        }
    }

    fun onPermissionDenied() {
        _hardwareState.value = BleHardwareState.PERMISSIONS_REQUIRED
        _lastError.value = "Bluetooth permissions denied. Cannot scan or advertise."
        _statusLog.value = "Permissions denied. BLE discovery and advertising unavailable."
    }

    fun refreshHardwareState() {
        if (!isBleSupported() || bluetoothAdapter == null) {
            _hardwareState.value = BleHardwareState.HARDWARE_UNAVAILABLE
            _statusLog.value = "Bluetooth Low Energy hardware not available on this device"
            return
        }

        if (!hasRequiredPermissions()) {
            _hardwareState.value = BleHardwareState.PERMISSIONS_REQUIRED
            _statusLog.value = "Missing required Android Bluetooth permissions"
            return
        }

        if (!isBluetoothEnabled()) {
            _hardwareState.value = BleHardwareState.BLUETOOTH_DISABLED
            _isScanning.value = false
            _isAdvertising.value = false
            _statusLog.value = "Bluetooth radio is powered OFF"
            return
        }

        if (_isAdvertising.value) {
            _hardwareState.value = BleHardwareState.ADVERTISING
        } else if (_isScanning.value) {
            _hardwareState.value = BleHardwareState.SCANNING
        } else if (_connectedPeerAddress.value != null) {
            _hardwareState.value = BleHardwareState.CONNECTED
        } else {
            _hardwareState.value = BleHardwareState.READY_IDLE
            _statusLog.value = "Radio Ready: Physical BLE adapter operational"
        }
    }

    @SuppressLint("MissingPermission")
    fun startAdvertising() {
        if (!isBleSupported() || bluetoothAdapter == null) {
            _lastError.value = "Cannot advertise: BLE hardware unavailable on this device"
            refreshHardwareState()
            return
        }

        if (!hasRequiredPermissions()) {
            _lastError.value = "Cannot advertise: Bluetooth permissions missing"
            refreshHardwareState()
            return
        }

        if (!isBluetoothEnabled()) {
            _lastError.value = "Cannot advertise: Bluetooth is disabled. Please turn on Bluetooth."
            refreshHardwareState()
            return
        }

        advertiser = bluetoothAdapter.bluetoothLeAdvertiser
        if (advertiser == null) {
            _lastError.value = "BluetoothLeAdvertiser not supported by this chipset"
            return
        }

        // Initialize local GATT server to receive incoming writes from peers
        setupGattServer()

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(true)
            .setTimeout(0)
            .build()

        // Keep primary advertisement packet compact (under 31 bytes) to fit 128-bit UUID reliably
        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .setIncludeTxPowerLevel(false)
            .addServiceUuid(ParcelUuid(BleConstants.SERVICE_UUID))
            .build()

        // Scan response carries our stable id + short name (4..22 bytes) as manufacturer data.
        // The raw device name is NOT included: it could overflow the 31-byte limit.
        val idBytes = (localNodeId + "|" + localNodeName).toByteArray(Charsets.UTF_8)
        val scanResponse = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addManufacturerData(BleConstants.MANUFACTURER_ID, idBytes)
            .build()

        try {
            advertiser?.startAdvertising(settings, data, scanResponse, advertiseCallback)
            _statusLog.value = "Started BLE advertising with Service UUID 0xFD42"
        } catch (e: SecurityException) {
            _lastError.value = "SecurityException starting advertising: ${e.message}"
            _isAdvertising.value = false
        } catch (e: Exception) {
            _lastError.value = "Failed to start advertising: ${e.message}"
            _isAdvertising.value = false
        }
    }

    @SuppressLint("MissingPermission")
    fun stopAdvertising() {
        if (!hasRequiredPermissions()) return
        try {
            advertiser?.stopAdvertising(advertiseCallback)
            _isAdvertising.value = false
            _statusLog.value = "Stopped BLE advertising"
            refreshHardwareState()
        } catch (e: Exception) {
            // Ignore on cleanup
        }
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            _isAdvertising.value = true
            _hardwareState.value = BleHardwareState.ADVERTISING
            _lastError.value = null
            _statusLog.value = "Advertising as $localNodeName ($localNodeId) - key fingerprint $myKeyFingerprint"
        }

        override fun onStartFailure(errorCode: Int) {
            _isAdvertising.value = false
            val errorMsg = when (errorCode) {
                ADVERTISE_FAILED_ALREADY_STARTED -> "Advertising already started"
                ADVERTISE_FAILED_DATA_TOO_LARGE -> "Advertise data exceeds 31-byte limit"
                ADVERTISE_FAILED_FEATURE_UNSUPPORTED -> "Advertising unsupported on this hardware"
                ADVERTISE_FAILED_INTERNAL_ERROR -> "Internal Bluetooth controller error"
                ADVERTISE_FAILED_TOO_MANY_ADVERTISERS -> "Too many active advertisers"
                else -> "Advertise error code $errorCode"
            }
            _lastError.value = errorMsg
            _statusLog.value = "Advertise failed: $errorMsg"
            refreshHardwareState()
        }
    }

    @SuppressLint("MissingPermission")
    private fun setupGattServer() {
        if (gattServer != null) return
        if (!hasRequiredPermissions()) return

        try {
            gattServer = bluetoothManager?.openGattServer(context, gattServerCallback)
            if (gattServer == null) {
                _lastError.value = "Failed to open BluetoothGattServer"
                return
            }

            val service = BluetoothGattService(
                BleConstants.SERVICE_UUID,
                BluetoothGattService.SERVICE_TYPE_PRIMARY
            )

            val messageChar = BluetoothGattCharacteristic(
                BleConstants.CHAR_MESSAGE_UUID,
                BluetoothGattCharacteristic.PROPERTY_READ or
                        BluetoothGattCharacteristic.PROPERTY_WRITE or
                        BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
                BluetoothGattCharacteristic.PERMISSION_READ or
                        BluetoothGattCharacteristic.PERMISSION_WRITE
            )

            service.addCharacteristic(messageChar)

            // ACK characteristic: server notifies the sender once the message is saved
            val ackChar = BluetoothGattCharacteristic(
                BleConstants.CHAR_ACK_UUID,
                BluetoothGattCharacteristic.PROPERTY_NOTIFY,
                BluetoothGattCharacteristic.PERMISSION_READ
            )
            ackChar.addDescriptor(
                android.bluetooth.BluetoothGattDescriptor(
                    BleConstants.CCCD_UUID,
                    android.bluetooth.BluetoothGattDescriptor.PERMISSION_READ or
                            android.bluetooth.BluetoothGattDescriptor.PERMISSION_WRITE
                )
            )
            service.addCharacteristic(ackChar)

            val keyChar = BluetoothGattCharacteristic(
                BleConstants.CHAR_PUBKEY_UUID,
                BluetoothGattCharacteristic.PROPERTY_READ,
                BluetoothGattCharacteristic.PERMISSION_READ
            )
            service.addCharacteristic(keyChar)
            gattServer?.addService(service)
            _statusLog.value = "GATT Server configured with characteristic 0xFD43"
        } catch (e: SecurityException) {
            _lastError.value = "Permission error opening GATT server: ${e.message}"
        } catch (e: Exception) {
            _lastError.value = "Error configuring GATT server: ${e.message}"
        }
    }


    /** Parsed multi-hop frame: G (group broadcast) or R (relayed personal message). */
    private data class MeshFrame(
        val kind: String, val msgId: String, val target: String, val ttl: Int,
        val originId: String, val originName: String, val viaId: String, val text: String
    )

    private fun parseMeshFrame(raw: String): MeshFrame? {
        // ML1|G|msgId|groupId|ttl|originId|originName|viaId|text   (text may contain '|')
        // ML1|R|msgId|destId |ttl|originId|originName|viaId|text
        val p = raw.split("|", limit = 9)
        if (p.size != 9 || (p[1] != "G" && p[1] != "R")) return null
        val ttl = p[4].toIntOrNull() ?: return null
        return MeshFrame(p[1], p[2], p[3], ttl, p[5], p[6], p[7], p[8])
    }

    private fun buildMeshFrame(f: MeshFrame): String =
        "${BleConstants.PROTO_PREFIX}${f.kind}|${f.msgId}|${f.target}|${f.ttl}|${f.originId}|" +
                "${f.originName}|${f.viaId}|${f.text}"

    /** Peers seen recently, excluding the given node ids (origin / previous hop). */
    private fun freshPeers(excludeIds: Set<String>): List<DiscoveredPeerDevice> {
        val cutoff = System.currentTimeMillis() - BleConstants.PEER_FRESH_MS
        return _discoveredPeers.value.filter {
            it.lastSeenMs >= cutoff && (it.nodeId == null || it.nodeId !in excludeIds) &&
                it.nodeId != localNodeId && !isLinkBroken(it.nodeId)
        }
    }

    private fun markSeen(id: String): Boolean {          // true = first time we see it
        val first = seenIncomingIds.add(id)
        if (seenIncomingIds.size > 500) synchronized(seenIncomingIds) {
            seenIncomingIds.iterator().let { if (it.hasNext()) { it.next(); it.remove() } }
        }
        return first
    }

    private fun enqueueFlood(frame: MeshFrame, peers: List<DiscoveredPeerDevice>, notify: Boolean): Int {
        val text = buildMeshFrame(frame)
        synchronized(sendQueue) {
            peers.forEach {
                sendQueue.add(QueuedSend(it.device, frame.text, frame.msgId, text,
                    expectAck = false, broadcast = true, notify = notify))
            }
        }
        if (peers.isNotEmpty()) mainHandler.post { startNextQueuedSend() }
        return peers.size
    }

    /** Group/channel broadcast. Returns how many nearby peers it was queued for (0 = nobody in range). */
    fun broadcastGroupMessage(groupId: String, text: String, msgId: String): Int {
        if (!hasRequiredPermissions()) { _lastError.value = "Permissions missing for Bluetooth transmission"; return 0 }
        markSeen(msgId)                                   // don't re-save our own message if a relay echoes it
        val frame = MeshFrame("G", msgId, groupId, BleConstants.DEFAULT_TTL, localNodeId, localNodeName, localNodeId, text.trim())
        return enqueueFlood(frame, freshPeers(emptySet()), notify = true)
    }

    /**
     * Personal message to a phone that is NOT directly reachable.
     * Uses a learned route (one next hop) when we have one; otherwise floods so relays can carry it.
     */
    fun sendRelayedMessage(destNodeId: String, text: String, msgId: String): Int {
        if (!hasRequiredPermissions()) { _lastError.value = "Permissions missing for Bluetooth transmission"; return 0 }
        markSeen(msgId)
        val frame = MeshFrame("R", msgId, destNodeId, BleConstants.DEFAULT_TTL, localNodeId, localNodeName, localNodeId, text.trim())

        val route = routes[destNodeId]
        val hop = route?.let { r -> freshPeers(emptySet()).firstOrNull { it.nodeId == r.nextHopNodeId } }
        if (hop != null) {
            _statusLog.value = "Using learned route to $destNodeId via ${hop.nodeId}"
            synchronized(sendQueue) {
                sendQueue.add(QueuedSend(hop.device, frame.text, frame.msgId, buildMeshFrame(frame),
                    expectAck = false, broadcast = true, notify = true, routeDest = destNodeId))
            }
            mainHandler.post { startNextQueuedSend() }
            return 1
        }
        return enqueueFlood(frame, freshPeers(emptySet()), notify = true)
    }

    fun hasFreshPeers(): Boolean = freshPeers(emptySet()).isNotEmpty()

    private val pendingForwards = java.util.Collections.synchronizedList(mutableListOf<MeshFrame>())

    /** Relay: forward a frame we received for someone else. Retries once after a quick scan if no peer is known. */
    private fun forward(frame: MeshFrame) {
        if (frame.ttl <= 1) return                        // hop budget used up
        val next = frame.copy(ttl = frame.ttl - 1, viaId = localNodeId)
        val peers = freshPeers(setOf(frame.originId, frame.viaId))
        if (peers.isNotEmpty()) {
            enqueueFlood(next, peers, notify = false)
        } else {
            pendingForwards.add(next)
            mainHandler.post { if (!_isScanning.value) startScanning() }
            mainHandler.postDelayed({
                val retry = synchronized(pendingForwards) { pendingForwards.toList().also { pendingForwards.clear() } }
                retry.forEach { f ->
                    val ps = freshPeers(setOf(f.originId, f.viaId))
                    if (ps.isNotEmpty()) enqueueFlood(f, ps, notify = false)
                }
            }, 8000L)
        }
    }

    private val seenIncomingIds = java.util.Collections.synchronizedSet(LinkedHashSet<String>())

    /** Parses and stores an incoming frame. Returns the message id to ACK (direct "M" frames only), or null. */
    @SuppressLint("MissingPermission")
    private fun deliverIncoming(device: BluetoothDevice?, value: ByteArray): String? {
        val raw = String(value, Charsets.UTF_8)
        if (raw.isBlank()) return null
        val timeStr = SimpleDateFormat("h:mm:ss a", Locale.getDefault()).format(Date())

        // ---- multi-hop frames (group broadcast / relayed personal) ----
        if (raw.startsWith(BleConstants.PROTO_PREFIX + "G|") || raw.startsWith(BleConstants.PROTO_PREFIX + "R|")) {
            val f = parseMeshFrame(raw) ?: return null
            if (!markSeen(f.msgId)) return null            // loop / duplicate protection
            if (f.originId == localNodeId) return null     // our own message came back around
            learnRoute(f.originId, f.viaId)                // to reach origin later: go back through whoever gave it to us

            if (f.kind == "G") {
                _nativeMessages.update {
                    it + NativeBleMessage(f.msgId, f.originId, f.originName, f.text, timeStr, false, "Group (hop ${BleConstants.DEFAULT_TTL - f.ttl + 1})", true)
                }
                persistenceListener?.onIncomingGroupMessage(f.msgId, f.target, f.originId, f.originName, f.text)
                forward(f)                                  // groups are for everyone: keep flooding
            } else if (f.target == localNodeId) {
                _nativeMessages.update {
                    it + NativeBleMessage(f.msgId, f.originId, f.originName, f.text, timeStr, false, "Received via relay", true)
                }
                persistenceListener?.onIncomingMessageReceived(f.msgId, f.originId, f.originName, f.text)
            } else {
                forward(f)                                  // not for us: pass it on
            }
            return null
        }

        // ---- direct message ----
        var senderId = device?.address ?: "UNKNOWN_ADDR"
        var senderName = try { device?.name ?: "Nearby BLE Peer" } catch (e: SecurityException) { "Nearby BLE Peer" }
        var text = raw
        var msgId: String? = null

        if (raw.startsWith(BleConstants.PROTO_PREFIX + "E|")) {
            // ML1|E|<msgId>|<senderId>|<senderName>|<senderPublicKeyB64>|<ciphertextB64>
            val e = raw.split("|", limit = 7)
            if (e.size != 7) return null
            val plain = try {
                val pub = Base64.decode(e[5], Base64.NO_WRAP)
                if (!pinOrCheckKey(e[3], pub)) null
                else crypto.decrypt(
                    crypto.sharedKey(pub),
                    Base64.decode(e[6], Base64.NO_WRAP),
                    "${e[2]}|${e[3]}".toByteArray(Charsets.UTF_8)
                )
            } catch (ex: Exception) { null }
            if (plain == null) {
                _lastError.value = "Dropped a message: decryption/authentication failed or sender key changed"
                return null
            }
            msgId = e[2]
            senderId = e[3]
            senderName = e[4]
            text = String(plain, Charsets.UTF_8)
        } else if (raw.startsWith(BleConstants.PROTO_PREFIX)) {
            return null                   // plaintext "M" frames are no longer accepted (spoofable)
        }

        if (msgId != null) learnRoute(senderId, senderId)   // direct neighbour

        // Duplicate (sender retried): don't save twice, but still ACK it
        if (msgId != null && !markSeen(msgId)) return msgId

        val newMsg = NativeBleMessage(
            id = msgId ?: ("RX_" + UUID.randomUUID().toString().take(6)),
            senderAddress = senderId,
            senderName = senderName,
            text = text,
            timestamp = timeStr,
            isOutgoing = false,
            deliveryStatus = "Received (Direct BLE)",
            isAckReceived = true
        )
        _nativeMessages.update { it + newMsg }
        _statusLog.value = "Received ${value.size} bytes from $senderName ($senderId)"
        persistenceListener?.onIncomingMessageReceived(newMsg.id, senderId, senderName, text)
        return msgId
    }

    @SuppressLint("MissingPermission")
    private fun sendAck(device: BluetoothDevice, msgId: String) {
        val server = gattServer ?: return
        val ackChar = server.getService(BleConstants.SERVICE_UUID)
            ?.getCharacteristic(BleConstants.CHAR_ACK_UUID) ?: return
        val bytes = "${BleConstants.PROTO_PREFIX}A|$msgId".toByteArray(Charsets.UTF_8)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                server.notifyCharacteristicChanged(device, ackChar, false, bytes)
            } else {
                @Suppress("DEPRECATION")
                ackChar.value = bytes
                @Suppress("DEPRECATION")
                server.notifyCharacteristicChanged(device, ackChar, false)
            }
        } catch (e: SecurityException) {
            // ignored
        } catch (e: Exception) {
            _lastError.value = "ACK send failed: ${e.message}"
        }
    }

    private val gattServerCallback = object : BluetoothGattServerCallback() {
        @SuppressLint("MissingPermission")
        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice?,
            requestId: Int,
            characteristic: BluetoothGattCharacteristic?,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray?
        ) {
            super.onCharacteristicWriteRequest(
                device,
                requestId,
                characteristic,
                preparedWrite,
                responseNeeded,
                offset,
                value
            )

            var ackId: String? = null
            if (characteristic?.uuid == BleConstants.CHAR_MESSAGE_UUID && value != null) {
                val senderAddr = device?.address ?: "UNKNOWN_ADDR"
                if (preparedWrite) {
                    // FIX: long write chunk -> buffer it, deliver on onExecuteWrite
                    val buf = preparedWriteBuffers.getOrPut(senderAddr) { java.io.ByteArrayOutputStream() }
                    synchronized(buf) { buf.write(value) }
                } else {
                    ackId = deliverIncoming(device, value)
                }
            }

            if (responseNeeded && device != null) {
                try {
                    gattServer?.sendResponse(
                        device,
                        requestId,
                        BluetoothGatt.GATT_SUCCESS,
                        offset,
                        value
                    )
                } catch (e: SecurityException) {
                    // Ignored
                }
            }
            if (ackId != null && device != null) sendAck(device, ackId)
        }

        @SuppressLint("MissingPermission")
        override fun onCharacteristicReadRequest(
            device: BluetoothDevice?,
            requestId: Int,
            offset: Int,
            characteristic: BluetoothGattCharacteristic?
        ) {
            if (device == null) return
            try {
                if (characteristic?.uuid == BleConstants.CHAR_PUBKEY_UUID) {
                    val key = crypto.publicKeyBytes
                    if (offset > key.size) {
                        gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_INVALID_OFFSET, offset, null)
                    } else {
                        gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset,
                            key.copyOfRange(offset, key.size))
                    }
                } else {
                    gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_READ_NOT_PERMITTED, offset, null)
                }
            } catch (e: SecurityException) { /* ignored */ }
        }

        @SuppressLint("MissingPermission")
        override fun onDescriptorWriteRequest(
            device: BluetoothDevice?,
            requestId: Int,
            descriptor: android.bluetooth.BluetoothGattDescriptor?,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray?
        ) {
            // Without this response the sender's "enable notifications" step would hang
            if (responseNeeded && device != null) {
                try {
                    gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value)
                } catch (e: SecurityException) { /* ignored */ }
            }
        }

        @SuppressLint("MissingPermission")
        override fun onExecuteWrite(device: BluetoothDevice?, requestId: Int, execute: Boolean) {
            val addr = device?.address ?: "UNKNOWN_ADDR"
            val buf = preparedWriteBuffers.remove(addr)
            var ackId: String? = null
            if (execute && buf != null) {
                val bytes = synchronized(buf) { buf.toByteArray() }
                ackId = deliverIncoming(device, bytes)
            }
            try {
                if (device != null) {
                    gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
                }
            } catch (e: SecurityException) {
                // Ignored
            }
            if (ackId != null && device != null) sendAck(device, ackId)
        }

        override fun onConnectionStateChange(device: BluetoothDevice?, status: Int, newState: Int) {
            val addr = device?.address ?: "Peer"
            val devName = try { device?.name } catch (e: Exception) { null }
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                _connectedPeerAddress.value = addr
                updatePeerConnectionState(addr, devName, PeerConnectionState.CONNECTED)
                _hardwareState.value = BleHardwareState.CONNECTED
                _statusLog.value = "Incoming GATT connection from $addr"
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                preparedWriteBuffers.remove(addr)
                if (_connectedPeerAddress.value == addr) {
                    _connectedPeerAddress.value = null
                }
                updatePeerConnectionState(addr, devName, PeerConnectionState.DISCONNECTED)
                _statusLog.value = "Peer disconnected: $addr"
                refreshHardwareState()
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun startScanning() {
        if (!isBleSupported() || bluetoothAdapter == null) {
            _lastError.value = "Cannot scan: BLE hardware unavailable on this device"
            refreshHardwareState()
            return
        }

        if (!hasRequiredPermissions()) {
            _lastError.value = "Cannot scan: Bluetooth permissions missing"
            refreshHardwareState()
            return
        }

        if (!isBluetoothEnabled()) {
            _lastError.value = "Cannot scan: Bluetooth is disabled. Please turn on Bluetooth."
            refreshHardwareState()
            return
        }

        scanner = bluetoothAdapter.bluetoothLeScanner
        if (scanner == null) {
            _lastError.value = "BluetoothLeScanner not supported by this device"
            return
        }

        // Keep recently seen peers (relay needs them); drop only stale ones
        val cutoff = System.currentTimeMillis() - BleConstants.PEER_FRESH_MS
        _discoveredPeers.update { list -> list.filter { it.lastSeenMs >= cutoff } }

        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(BleConstants.SERVICE_UUID))
            .build()

        val scanSettings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        try {
            scanner?.startScan(listOf(filter), scanSettings, scanCallback)
            _isScanning.value = true
            _hardwareState.value = BleHardwareState.SCANNING
            _statusLog.value = "Started BLE scan for Service UUID 0xFD42 (20s timeout)"

            // Schedule auto scan timeout
            mainHandler.removeCallbacks(scanTimeoutRunnable)
            mainHandler.postDelayed(scanTimeoutRunnable, BleConstants.SCAN_TIMEOUT_MS)
        } catch (e: SecurityException) {
            _lastError.value = "SecurityException starting BLE scan: ${e.message}"
            _isScanning.value = false
        } catch (e: Exception) {
            _lastError.value = "Failed to start BLE scan: ${e.message}"
            _isScanning.value = false
        }
    }

    @SuppressLint("MissingPermission")
    fun stopScanning() {
        mainHandler.removeCallbacks(scanTimeoutRunnable)
        if (!hasRequiredPermissions()) {
            _isScanning.value = false
            return
        }
        try {
            scanner?.stopScan(scanCallback)
            _isScanning.value = false
            _statusLog.value = "Stopped BLE scan"
            refreshHardwareState()
        } catch (e: Exception) {
            _isScanning.value = false
        }
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            result ?: return
            val dev = result.device ?: return
            val address = dev.address ?: return

            // Safely parse name from scan record or device name
            // Our advertisement: manufacturer data = "<nodeId>|<shortName>"
            val mfr = result.scanRecord?.getManufacturerSpecificData(BleConstants.MANUFACTURER_ID)
                ?.let { String(it, Charsets.UTF_8) }
            val advNodeId = mfr?.substringBefore("|", "")?.takeIf { it.isNotBlank() }
            val advName = mfr?.substringAfter("|", "")?.takeIf { it.isNotBlank() }
            val recordName = advName ?: result.scanRecord?.deviceName?.takeIf { it.isNotBlank() }
            val devName = try {
                dev.name?.takeIf { it.isNotBlank() }
            } catch (e: SecurityException) {
                null
            } catch (e: Exception) {
                null
            }

            val fallbackName = "MeshLink Peer (${address.takeLast(5)})"
            _discoveredPeers.update { current ->
                val existingList = current.toMutableList()
                val index = existingList.indexOfFirst { it.address == address }
                val resolvedName = recordName
                    ?: devName
                    ?: (if (index >= 0 && !existingList[index].name.startsWith("MeshLink Peer")) {
                        existingList[index].name
                    } else {
                        fallbackName
                    })
                val updated = DiscoveredPeerDevice(
                    device = dev,
                    name = resolvedName,
                    address = address,
                    rssi = result.rssi,
                    lastSeenMs = System.currentTimeMillis(),
                    nodeId = advNodeId
                )
                if (index >= 0) existingList[index] = updated else existingList.add(updated)
                existingList
            }
            val resolvedName = _discoveredPeers.value.firstOrNull { it.address == address }?.name ?: fallbackName
            _statusLog.value = "Discovered peer: $resolvedName (${result.rssi} dBm)"
        }

        override fun onScanFailed(errorCode: Int) {
            mainHandler.removeCallbacks(scanTimeoutRunnable)
            _isScanning.value = false
            val errorMsg = when (errorCode) {
                SCAN_FAILED_ALREADY_STARTED -> "Scan already in progress"
                SCAN_FAILED_APPLICATION_REGISTRATION_FAILED -> "App registration failed"
                SCAN_FAILED_INTERNAL_ERROR -> "Internal BLE controller error"
                SCAN_FAILED_FEATURE_UNSUPPORTED -> "BLE scanning unsupported on this hardware"
                else -> "Scan error code $errorCode"
            }
            _lastError.value = errorMsg
            _statusLog.value = "Scan failed: $errorMsg"
            refreshHardwareState()
        }
    }

    /**
     * Queue a message for direct BLE delivery. Messages are sent one after another.
     * If [customMessageId] is given, the caller already saved the message to the DB.
     */
    fun sendDirectBleMessage(targetDevice: BluetoothDevice, messageText: String, customMessageId: String? = null) {
        if (!hasRequiredPermissions()) {
            _lastError.value = "Permissions missing for Bluetooth transmission"
            return
        }
        val trimmedText = messageText.trim()
        if (trimmedText.isEmpty()) return

        val messageId = customMessageId ?: ("TX_" + UUID.randomUUID().toString().take(6))
        val timeStr = SimpleDateFormat("h:mm:ss a", Locale.getDefault()).format(Date())

        _nativeMessages.update {
            it + NativeBleMessage(
                id = messageId,
                senderAddress = "This Phone",
                senderName = "Me",
                text = trimmedText,
                timestamp = timeStr,
                isOutgoing = true,
                deliveryStatus = "Queued",
                isAckReceived = false
            )
        }
        // FIX: only persist here when the caller did not already save it (avoids double insert
        // that could reset a DELIVERED/FAILED status back to PENDING).
        if (customMessageId == null) {
            val convId = _discoveredPeers.value.firstOrNull { it.address == targetDevice.address }?.nodeId
                ?: targetDevice.address
            persistenceListener?.onOutgoingMessageSaved(messageId, convId, trimmedText)
        }

        synchronized(sendQueue) { sendQueue.add(QueuedSend(targetDevice, trimmedText, messageId)) }
        mainHandler.post { startNextQueuedSend() }
    }

    @SuppressLint("MissingPermission")
    private fun startNextQueuedSend() {
        val next: QueuedSend = synchronized(sendQueue) {
            if (pendingOutgoingMessageId != null) return          // a transfer is in progress
            val item = sendQueue.poll() ?: return
            pendingOutgoingPayload = item.text
            pendingOutgoingMessageId = item.id
            pendingFrame = item.frame
            pendingExpectAck = item.expectAck
            pendingBroadcast = item.broadcast
            pendingNotify = item.notify
            pendingItem = item
            pendingSessionKey = null            // never reuse a previous peer's key
            item
        }

        val targetDevice = next.device
        val targetAddress = targetDevice.address
        val targetName = try { targetDevice.name } catch (e: Exception) { null }

        _nativeMessages.update { list ->
            list.map { if (it.id == next.id) it.copy(deliveryStatus = "Connecting...") else it }
        }
        _hardwareState.value = BleHardwareState.CONNECTING
        connectingDeviceAddress = targetAddress
        updatePeerConnectionState(targetAddress, targetName, PeerConnectionState.CONNECTING)
        _statusLog.value = "Connecting to peer GATT server at $targetAddress..."

        mainHandler.removeCallbacks(connectionTimeoutRunnable)
        mainHandler.postDelayed(connectionTimeoutRunnable, 15000L)

        try {
            activeClientGatt?.close()
            activeClientGatt = null
            activeClientGatt = targetDevice.connectGatt(
                context,
                false,
                clientGattCallback,
                BluetoothDevice.TRANSPORT_LE
            )
        } catch (e: SecurityException) {
            connectingDeviceAddress = null
            updatePeerConnectionState(targetAddress, targetName, PeerConnectionState.DISCONNECTED)
            markPendingMessageFailed("Permission error: ${e.message}")
        } catch (e: Exception) {
            connectingDeviceAddress = null
            updatePeerConnectionState(targetAddress, targetName, PeerConnectionState.DISCONNECTED)
            markPendingMessageFailed("Connection failed: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnectPeer(address: String? = null) {
        mainHandler.removeCallbacks(connectionTimeoutRunnable)
        val peerAddr = address ?: connectingDeviceAddress ?: _connectedPeerAddress.value
        try {
            activeClientGatt?.disconnect()
            activeClientGatt?.close()
            activeClientGatt = null
        } catch (e: Exception) {
            // Ignore
        }
        if (peerAddr != null) {
            updatePeerConnectionState(peerAddr, null, PeerConnectionState.DISCONNECTED)
            if (_connectedPeerAddress.value.equals(peerAddr, ignoreCase = true)) {
                _connectedPeerAddress.value = null
            }
        } else {
            _connectedPeerAddress.value = null
        }
        connectingDeviceAddress = null
        _statusLog.value = "Disconnected from peer ${peerAddr ?: ""}"
        refreshHardwareState()
    }

    private val clientGattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            // Late callback from a previous (already finished) link: just clean it up. Without this,
            // the old link's DISCONNECTED event could wrongly fail the next queued message.
            val current = activeClientGatt
            if (gatt != null && current != null && gatt !== current) {
                try { gatt.close() } catch (e: Exception) { /* ignore */ }
                return
            }
            mainHandler.removeCallbacks(connectionTimeoutRunnable)
            val devAddr = gatt?.device?.address ?: connectingDeviceAddress ?: "Peer"
            val devName = try { gatt?.device?.name } catch (e: Exception) { null }

            if (status != BluetoothGatt.GATT_SUCCESS) {
                _statusLog.value = "GATT connection status error: $status on $devAddr"
                updatePeerConnectionState(devAddr, devName, PeerConnectionState.DISCONNECTED)
                markPendingMessageFailed("GATT connection failed (code $status)")
                try {
                    gatt?.close()
                } catch (e: Exception) {
                    // Ignore
                }
                if (activeClientGatt == gatt) {
                    activeClientGatt = null
                }
                connectingDeviceAddress = null
                refreshHardwareState()
                return
            }

            if (newState == BluetoothProfile.STATE_CONNECTED) {
                _connectedPeerAddress.value = devAddr
                connectingDeviceAddress = null
                updatePeerConnectionState(devAddr, devName, PeerConnectionState.CONNECTED)
                _hardwareState.value = BleHardwareState.CONNECTED
                _statusLog.value = "GATT connected to $devAddr. Discovering services..."
                // FIX: re-arm the timeout (it was removed above) so a stuck discovery/write can't hang forever
                mainHandler.postDelayed(connectionTimeoutRunnable, 15000L)
                try {
                    // FIX: negotiate a bigger MTU first. Default MTU allows only 20 bytes, so any
                    // normal chat message used to be split/garbled. Discovery continues in onMtuChanged.
                    if (gatt?.requestMtu(BleConstants.TARGET_NEGOTIATED_MTU) != true) {
                        gatt?.discoverServices()
                    }
                } catch (e: SecurityException) {
                    markPendingMessageFailed("SecurityException on connect")
                }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                // FIX: peer dropped while a message was still pending -> mark it failed (was stuck "Connecting...")
                if (pendingOutgoingMessageId != null) {
                    if (awaitingAckForId != null) {
                        // write succeeded, peer just hung up before ACK arrived: keep "Sent"
                        mainHandler.removeCallbacks(ackTimeoutRunnable)
                        finishPending(null)
                    } else {
                        markPendingMessageFailed("Peer disconnected before delivery")
                    }
                }
                if (_connectedPeerAddress.value == devAddr) {
                    _connectedPeerAddress.value = null
                }
                connectingDeviceAddress = null
                updatePeerConnectionState(devAddr, devName, PeerConnectionState.DISCONNECTED)
                _statusLog.value = "GATT disconnected from peer $devAddr"
                try {
                    gatt?.close()
                } catch (e: Exception) {
                    // Ignore
                }
                if (activeClientGatt == gatt) {
                    activeClientGatt = null
                }
                refreshHardwareState()
            }
        }

        @SuppressLint("MissingPermission")
        override fun onMtuChanged(gatt: BluetoothGatt?, mtu: Int, status: Int) {
            _statusLog.value = "MTU negotiated: $mtu (status $status)"
            try {
                gatt?.discoverServices()
            } catch (e: SecurityException) {
                markPendingMessageFailed("SecurityException on discoverServices")
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS || gatt == null) {
                markPendingMessageFailed("Service discovery failed (status $status)")
                return
            }

            val service = gatt.getService(BleConstants.SERVICE_UUID)
            if (service == null) {
                markPendingMessageFailed("Target device did not advertise MeshLink Service 0xFD42")
                return
            }

            val characteristic = service.getCharacteristic(BleConstants.CHAR_MESSAGE_UUID)
            if (characteristic == null) {
                markPendingMessageFailed("MeshLink characteristic 0xFD43 not found on peer")
                return
            }

            if (pendingOutgoingPayload == null) return

            if (!pendingExpectAck) {          // broadcast / relay frames: fire and forget
                writeMessage(gatt)
                return
            }

            // Direct messages are end-to-end encrypted: read the peer's public key first.
            val keyChar = service.getCharacteristic(BleConstants.CHAR_PUBKEY_UUID)
            if (keyChar == null) {
                markPendingMessageFailed("Peer app has no encryption support - update the app on that phone")
                return
            }
            try {
                gatt.readCharacteristic(keyChar)
            } catch (e: SecurityException) {
                markPendingMessageFailed("SecurityException reading peer key")
            }
        }

        // API 33+
        override fun onCharacteristicRead(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray,
            status: Int
        ) {
            handleKeyRead(gatt, characteristic, value, status)
        }

        // API < 33
        @Deprecated("Deprecated in Java")
        @Suppress("DEPRECATION")
        override fun onCharacteristicRead(gatt: BluetoothGatt?, characteristic: BluetoothGattCharacteristic?, status: Int) {
            if (gatt != null && characteristic != null) {
                handleKeyRead(gatt, characteristic, characteristic.value ?: ByteArray(0), status)
            }
        }

        private fun handleKeyRead(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
            if (characteristic.uuid != BleConstants.CHAR_PUBKEY_UUID) return
            if (status != BluetoothGatt.GATT_SUCCESS || value.isEmpty()) {
                markPendingMessageFailed("Could not read peer encryption key (status $status)")
                return
            }
            try {
                val peerNode = nodeIdOfAddress(gatt.device.address) ?: gatt.device.address
                if (!pinOrCheckKey(peerNode, value)) {
                    markPendingMessageFailed("Peer's encryption key CHANGED - message blocked (possible impostor or reinstall)")
                    return
                }
                pendingSessionKey = crypto.sharedKey(value)
            } catch (e: Exception) {
                markPendingMessageFailed("Key agreement failed: ${e.message}")
                return
            }
            subscribeAckThenWrite(gatt)
        }

        @SuppressLint("MissingPermission")
        private fun subscribeAckThenWrite(gatt: BluetoothGatt) {
            val service = gatt.getService(BleConstants.SERVICE_UUID)
            // Subscribe to the ACK characteristic first; the message is written in onDescriptorWrite.
            val ackChar = service?.getCharacteristic(BleConstants.CHAR_ACK_UUID)
            val cccd = ackChar?.getDescriptor(BleConstants.CCCD_UUID)
            if (ackChar == null || cccd == null) {
                // Older peer without ACK support: send anyway (will stay "Sent", never "Delivered")
                writeMessage(gatt)
                return
            }
            try {
                gatt.setCharacteristicNotification(ackChar, true)
                val ok = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    gatt.writeDescriptor(cccd, android.bluetooth.BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) ==
                            BluetoothStatusCodes.SUCCESS
                } else {
                    @Suppress("DEPRECATION")
                    cccd.value = android.bluetooth.BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    @Suppress("DEPRECATION")
                    gatt.writeDescriptor(cccd)
                }
                if (!ok) writeMessage(gatt)
            } catch (e: SecurityException) {
                markPendingMessageFailed("SecurityException subscribing to ACK")
            } catch (e: Exception) {
                writeMessage(gatt)
            }
        }

        override fun onDescriptorWrite(
            gatt: BluetoothGatt?,
            descriptor: android.bluetooth.BluetoothGattDescriptor?,
            status: Int
        ) {
            // Whether or not the subscription worked, now send the message
            if (gatt != null) writeMessage(gatt)
        }

        // API 33+
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            handleAck(characteristic, value)
        }

        // API < 33
        @Deprecated("Deprecated in Java")
        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(gatt: BluetoothGatt?, characteristic: BluetoothGattCharacteristic?) {
            if (characteristic != null) handleAck(characteristic, characteristic.value ?: return)
        }

        private fun handleAck(characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (characteristic.uuid != BleConstants.CHAR_ACK_UUID) return
            val parts = String(value, Charsets.UTF_8).split("|")
            if (parts.size < 3 || parts[0] + "|" != BleConstants.PROTO_PREFIX || parts[1] != "A") return
            val ackedId = parts[2]
            if (ackedId != awaitingAckForId) return

            mainHandler.removeCallbacks(ackTimeoutRunnable)
            awaitingAckForId = null
            _nativeMessages.update { list ->
                list.map { msg ->
                    if (msg.id == ackedId) msg.copy(deliveryStatus = "Delivered (peer ACK)", isAckReceived = true) else msg
                }
            }
            // "Delivered" now really means: the other phone received AND stored the message
            persistenceListener?.onOutgoingMessageDelivered(ackedId)
            _statusLog.value = "ACK received from peer for $ackedId"
            finishPending(activeClientGatt)
        }

        @SuppressLint("MissingPermission")
        private fun writeMessage(gatt: BluetoothGatt) {
            val characteristic = gatt.getService(BleConstants.SERVICE_UUID)
                ?.getCharacteristic(BleConstants.CHAR_MESSAGE_UUID)
            val payload = pendingOutgoingPayload
            val msgId = pendingOutgoingMessageId
            if (characteristic == null || payload == null || msgId == null) return

            // Wire frame carries our stable id so the receiver files it under the right chat
            val frame = pendingFrame ?: run {
                val key = pendingSessionKey
                if (key == null) {
                    markPendingMessageFailed("No encryption key for peer - refusing to send in plaintext")
                    return
                }
                val aad = "$msgId|$localNodeId".toByteArray(Charsets.UTF_8)
                val cipher = Base64.encodeToString(crypto.encrypt(key, payload.toByteArray(Charsets.UTF_8), aad), Base64.NO_WRAP)
                val myPub = Base64.encodeToString(crypto.publicKeyBytes, Base64.NO_WRAP)
                "${BleConstants.PROTO_PREFIX}E|$msgId|$localNodeId|$localNodeName|$myPub|$cipher"
            }
            val bytes = frame.toByteArray(Charsets.UTF_8)

            _hardwareState.value = BleHardwareState.TRANSMITTING
            _statusLog.value = "Writing ${bytes.size} bytes to characteristic..."
            if (pendingNotify) persistenceListener?.onOutgoingMessageTransmitting(msgId)

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    gatt.writeCharacteristic(characteristic, bytes, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
                } else {
                    @Suppress("DEPRECATION")
                    characteristic.value = bytes
                    @Suppress("DEPRECATION")
                    characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                    @Suppress("DEPRECATION")
                    gatt.writeCharacteristic(characteristic)
                }
            } catch (e: SecurityException) {
                markPendingMessageFailed("SecurityException writing characteristic")
            } catch (e: Exception) {
                markPendingMessageFailed("Exception writing characteristic: ${e.message}")
            }
        }

        @SuppressLint("MissingPermission")
        override fun onCharacteristicWrite(
            gatt: BluetoothGatt?,
            characteristic: BluetoothGattCharacteristic?,
            status: Int
        ) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                mainHandler.removeCallbacks(connectionTimeoutRunnable)
                val msgId = pendingOutgoingMessageId ?: return
                // Write reached the other phone's Bluetooth stack = SENT. Not yet DELIVERED:
                // that only happens when the peer's app confirms with an ACK notification.
                _nativeMessages.update { list ->
                    list.map { if (it.id == msgId) it.copy(deliveryStatus = "Sent (waiting for ACK)") else it }
                }
                if (pendingNotify) persistenceListener?.onOutgoingMessageTransmitting(msgId)
                if (!pendingExpectAck) {
                    // Broadcast / relay: no end-to-end ACK exists. Remember at least one peer got it.
                    if (pendingBroadcast) broadcastSucceeded.add(msgId)
                    recordLinkSuccess(nodeIdOfAddress(gatt?.device?.address))
                    _statusLog.value = "Frame handed to peer (broadcast/relay, no ACK)"
                    finishPending(gatt)
                    return
                }
                _statusLog.value = "Write OK. Waiting for peer ACK..."
                awaitingAckForId = msgId
                mainHandler.removeCallbacks(ackTimeoutRunnable)
                mainHandler.postDelayed(ackTimeoutRunnable, BleConstants.ACK_TIMEOUT_MS)
            } else {
                markPendingMessageFailed("Write failed with GATT status $status")
            }
        }
    }

    /** Ends the current transfer (ACKed or timed out), closes the link and starts the next queued message. */
    @SuppressLint("MissingPermission")
    private fun finishPending(gatt: BluetoothGatt?) {
        mainHandler.removeCallbacks(connectionTimeoutRunnable)
        mainHandler.removeCallbacks(ackTimeoutRunnable)
        awaitingAckForId = null
        pendingOutgoingPayload = null
        pendingOutgoingMessageId = null
        try { gatt?.disconnect() } catch (e: Exception) { /* ignore */ }
        _hardwareState.value = if (_connectedPeerAddress.value != null) BleHardwareState.CONNECTED else BleHardwareState.READY_IDLE
        mainHandler.postDelayed({ startNextQueuedSend() }, 300)
    }

    private fun markPendingMessageFailed(reason: String) {
        mainHandler.removeCallbacks(connectionTimeoutRunnable)
        mainHandler.removeCallbacks(ackTimeoutRunnable)
        awaitingAckForId = null

        // Link-health bookkeeping + SELF-HEALING: a unicast along a learned route failed ->
        // forget that route and re-send the same frame by flooding through the other neighbours.
        val failedItem = if (pendingOutgoingMessageId != null) pendingItem else null   // ignore duplicate failure events
        val failedNode = nodeIdOfAddress(failedItem?.device?.address)
        if (failedItem != null) recordLinkFailure(failedNode)
        if (failedItem?.routeDest != null && failedItem.frame != null) {
            routes.remove(failedItem.routeDest)
            val f = parseMeshFrame(failedItem.frame)
            val others = freshPeers(setOfNotNull(failedNode))
            if (f != null && others.isNotEmpty()) {
                _statusLog.value = "Route via $failedNode broke - re-sending through ${others.size} other neighbour(s)"
                enqueueFlood(f, others, failedItem.notify)
                pendingOutgoingPayload = null
                pendingOutgoingMessageId = null
                pendingItem = null
                _hardwareState.value = if (_connectedPeerAddress.value != null) BleHardwareState.CONNECTED else BleHardwareState.READY_IDLE
                mainHandler.postDelayed({ startNextQueuedSend() }, 300)
                return                                         // rerouted: don't report Failed
            }
        }
        val msgId = pendingOutgoingMessageId
        if (msgId != null) {
            val partiallyDelivered = pendingBroadcast && broadcastSucceeded.contains(msgId)
            if (!partiallyDelivered) {
                _nativeMessages.update { list ->
                    list.map { msg ->
                        if (msg.id == msgId) msg.copy(deliveryStatus = "Delivery Failed: $reason") else msg
                    }
                }
                if (pendingNotify) persistenceListener?.onOutgoingMessageFailed(msgId, reason)
            }
        }
        _lastError.value = reason
        pendingOutgoingPayload = null
        pendingOutgoingMessageId = null
        _hardwareState.value = if (_connectedPeerAddress.value != null) BleHardwareState.CONNECTED else BleHardwareState.READY_IDLE
        // FIX: keep processing the queue after a failure
        mainHandler.postDelayed({ startNextQueuedSend() }, 300)
    }

    fun clearError() {
        _lastError.value = null
    }

    @SuppressLint("MissingPermission")
    fun cleanup() {
        mainHandler.removeCallbacks(scanTimeoutRunnable)
        mainHandler.removeCallbacks(connectionTimeoutRunnable)
        mainHandler.removeCallbacks(ackTimeoutRunnable)
        synchronized(sendQueue) { sendQueue.clear() }
        preparedWriteBuffers.clear()
        stopAdvertising()
        stopScanning()
        try {
            gattServer?.close()
            gattServer = null
        } catch (e: Exception) {
            // Ignore
        }
        try {
            activeClientGatt?.disconnect()
            activeClientGatt?.close()
            activeClientGatt = null
        } catch (e: Exception) {
            // Ignore
        }
        connectingDeviceAddress = null
    }
}

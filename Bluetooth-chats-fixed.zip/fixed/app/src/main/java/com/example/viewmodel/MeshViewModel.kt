package com.example.viewmodel

import android.app.Application
import android.bluetooth.BluetoothDevice
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ble.BleHardwareState
import com.example.ble.BleMeshManager
import com.example.ble.BleMessagePersistenceListener
import com.example.ble.DiscoveredPeerDevice
import com.example.ble.NativeBleMessage
import com.example.data.MockMeshRepository
import com.example.model.ChatMessage
import com.example.model.GroupChannel
import com.example.model.MessageDeliveryStatus
import com.example.model.MeshPacketFrame
import com.example.model.MeshRouteEntry
import com.example.model.PeerNode
import com.example.model.PersonalConversation
import com.example.model.TechnicalSpecItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class HomeSection(val title: String) {
    PERSONAL_CHATS("Chats"),
    NEARBY_GROUPS("Groups"),
    MESH_NETWORK("Network")
}

data class MeshUiState(
    val currentSection: HomeSection = HomeSection.PERSONAL_CHATS,
    val selectedPersonalChatId: String? = null,
    val selectedGroupId: String? = null,
    val inspectedPacket: MeshPacketFrame? = null,
    val showDiagnosticsScreen: Boolean = false,
    val showNewPairDialog: Boolean = false,
    val lastSentDraftNotice: String? = null,
    val selectedBlePeer: DiscoveredPeerDevice? = null
)

class MeshViewModel(
    application: Application,
    val repository: MockMeshRepository
) : AndroidViewModel(application) {

    constructor(application: Application) : this(application, MockMeshRepository(application.applicationContext))

    // Native BLE Hardware Subsystem
    val bleManager = BleMeshManager(application.applicationContext)

    val bleHardwareState: StateFlow<BleHardwareState> = bleManager.hardwareState
    val isBleAdvertising: StateFlow<Boolean> = bleManager.isAdvertising
    val isBleScanning: StateFlow<Boolean> = bleManager.isScanning
    val discoveredBlePeers: StateFlow<List<DiscoveredPeerDevice>> = bleManager.discoveredPeers
    val connectedPeerAddress: StateFlow<String?> = bleManager.connectedPeerAddress
    val peerConnectionStates: StateFlow<Map<String, com.example.ble.PeerConnectionInfo>> = bleManager.peerConnectionStates
    val nativeBleMessages: StateFlow<List<NativeBleMessage>> = bleManager.nativeMessages
    val bleLastError: StateFlow<String?> = bleManager.lastError
    val bleStatusLog: StateFlow<String?> = bleManager.statusLog

    private val _uiState = MutableStateFlow(MeshUiState())
    val uiState: StateFlow<MeshUiState> = _uiState.asStateFlow()

    val conversations: StateFlow<List<PersonalConversation>> = repository.conversations
    val groupChannels: StateFlow<List<GroupChannel>> = repository.groupChannels
    val routeTable: StateFlow<List<MeshRouteEntry>> = repository.routeTable
    val discoveredNodes: StateFlow<List<PeerNode>> = repository.discoveredNodes
    val technicalSpecs: List<TechnicalSpecItem> = repository.getTechnicalSpecifications()

    init {
        // Wire BLE hardware manager to SQLite persistence layer
        bleManager.persistenceListener = object : BleMessagePersistenceListener {
            override fun onOutgoingMessageSaved(messageId: String, peerAddress: String, text: String) {
                viewModelScope.launch {
                    repository.saveOutgoingPersistentMessage(
                        convId = peerAddress,
                        text = text,
                        isGroup = false,
                        customId = messageId
                    )
                }
            }

            override fun onOutgoingMessageTransmitting(messageId: String) {
                viewModelScope.launch {
                    repository.updateDeliveryStatus(
                        messageId = messageId,
                        convId = null,
                        status = MessageDeliveryStatus.SENT,
                        isAckReceived = false
                    )
                }
            }

            override fun onOutgoingMessageDelivered(messageId: String) {
                viewModelScope.launch {
                    repository.updateDeliveryStatus(
                        messageId = messageId,
                        convId = null,
                        status = MessageDeliveryStatus.DELIVERED,
                        isAckReceived = true
                    )
                }
            }

            override fun onOutgoingMessageFailed(messageId: String, reason: String) {
                viewModelScope.launch {
                    repository.updateDeliveryStatus(
                        messageId = messageId,
                        convId = null,
                        status = MessageDeliveryStatus.FAILED,
                        isAckReceived = false
                    )
                }
            }

            override fun onIncomingGroupMessage(
                messageId: String,
                groupId: String,
                senderId: String,
                senderName: String,
                text: String
            ) {
                viewModelScope.launch {
                    repository.saveIncomingGroupMessage(groupId, senderId, senderName, text, messageId)
                }
            }

            override fun onIncomingMessageReceived(
                messageId: String,
                senderAddress: String,
                senderName: String,
                text: String
            ) {
                viewModelScope.launch {
                    repository.saveIncomingBleMessage(
                        senderAddr = senderAddress,
                        senderName = senderName,
                        text = text,
                        customId = messageId
                    )
                }
            }
        }
    }

    // ---- Outbox: messages that could not be sent yet (nobody in range) are retried when a phone shows up ----
    private data class OutboxItem(val convId: String, val text: String, val isGroup: Boolean, val msgId: String)
    private val outbox = mutableListOf<OutboxItem>()

    init {
        viewModelScope.launch {
            discoveredBlePeers.collect { if (it.isNotEmpty()) flushOutbox() }
        }
    }

    private fun flushOutbox() {
        if (outbox.isEmpty()) return
        val items = outbox.toList()
        outbox.clear()
        items.forEach { if (!dispatchOutgoing(it)) outbox.add(it) }
    }

    /** Picks the right path: direct BLE, group broadcast, or relay flood. Returns false if nobody is reachable. */
    private fun dispatchOutgoing(item: OutboxItem): Boolean {
        val freshAfter = System.currentTimeMillis() - com.example.ble.BleConstants.PEER_FRESH_MS
        if (item.isGroup) {
            val n = bleManager.broadcastGroupMessage(item.convId, item.text, item.msgId)
            if (n > 0) {
                _uiState.value = _uiState.value.copy(
                    lastSentDraftNotice = "Group message sent to $n nearby phone(s). Best effort - no delivery confirmation."
                )
                return true
            }
            return false
        }
        val direct = discoveredBlePeers.value.find {
            it.lastSeenMs >= freshAfter &&
                (it.nodeId.equals(item.convId, ignoreCase = true) || it.address.equals(item.convId, ignoreCase = true))
        }
        if (direct != null) {
            bleManager.sendDirectBleMessage(direct.device, item.text, item.msgId)
            _uiState.value = _uiState.value.copy(lastSentDraftNotice = "Saved locally. Transmitting via direct BLE...")
            return true
        }
        val n = bleManager.sendRelayedMessage(item.convId, item.text, item.msgId)
        if (n > 0) {
            _uiState.value = _uiState.value.copy(
                lastSentDraftNotice = "Peer not in direct range. Sent via $n nearby phone(s) for relay (no delivery confirmation)."
            )
            return true
        }
        return false
    }

    fun selectSection(section: HomeSection) {
        _uiState.value = _uiState.value.copy(
            currentSection = section,
            selectedPersonalChatId = null,
            selectedGroupId = null
        )
    }

    fun openPersonalChat(chatId: String) {
        _uiState.value = _uiState.value.copy(
            selectedPersonalChatId = chatId,
            selectedGroupId = null
        )
    }

    fun openGroupChat(groupId: String) {
        _uiState.value = _uiState.value.copy(
            selectedGroupId = groupId,
            selectedPersonalChatId = null
        )
    }

    fun closeActiveChat() {
        _uiState.value = _uiState.value.copy(
            selectedPersonalChatId = null,
            selectedGroupId = null
        )
    }

    fun openDiagnostics() {
        _uiState.value = _uiState.value.copy(showDiagnosticsScreen = true)
    }

    fun closeDiagnostics() {
        _uiState.value = _uiState.value.copy(showDiagnosticsScreen = false)
    }

    fun inspectMessagePacket(message: ChatMessage) {
        val packet = repository.generatePacketFrame(message)
        _uiState.value = _uiState.value.copy(inspectedPacket = packet)
    }

    fun dismissPacketInspection() {
        _uiState.value = _uiState.value.copy(inspectedPacket = null)
    }

    fun openNewPairDialog() {
        _uiState.value = _uiState.value.copy(showNewPairDialog = true)
    }

    fun closeNewPairDialog() {
        _uiState.value = _uiState.value.copy(showNewPairDialog = false)
    }

    fun sendMessage(convId: String, text: String, isGroup: Boolean = false): ChatMessage {
        val formatter = java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault())
        val timeStr = formatter.format(java.util.Date())
        val msgId = "TX_" + java.util.UUID.randomUUID().toString().take(6)

        val localMsg = ChatMessage(
            id = msgId,
            conversationId = convId,
            senderNodeId = repository.localNodeId,
            senderName = "Me",
            isOutgoing = true,
            text = text,
            timestampFormatted = timeStr,
            deliveryStatus = MessageDeliveryStatus.PENDING,
            hopsTraversed = 0,
            maxHops = if (isGroup) 4 else 3,
            routePath = listOf(repository.localNodeId),
            isE2EEncrypted = false,
            estimatedPacketBytes = text.toByteArray().size + 42
        )
        repository.addLocalMessage(localMsg)

        viewModelScope.launch {
            // Persist to Room SQLite
            repository.saveOutgoingPersistentMessage(convId, text, isGroup, msgId)

            val item = OutboxItem(convId, text, isGroup, msgId)
            if (!dispatchOutgoing(item)) {
                outbox.add(item)
                _uiState.value = _uiState.value.copy(
                    lastSentDraftNotice = "Saved. No MeshLink phone in range - will send automatically when one is found (tap Scan)."
                )
            }
        }

        return localMsg
    }

    fun sendLocalDraft(convId: String, text: String, isGroup: Boolean) {
        sendMessage(convId, text, isGroup)
    }

    fun startChatWithBlePeer(peer: DiscoveredPeerDevice) {
        viewModelScope.launch {
            // Use the peer's stable id (from its advertisement); BLE MAC addresses rotate
            val conv = repository.getOrCreateRealConversation(peer.nodeId ?: peer.address, peer.name)
            openPersonalChat(conv.id)
        }
    }

    fun getMessagesForConversation(convId: String): List<ChatMessage> {
        return repository.getMessagesForConversation(convId)
    }

    fun getMessagesFlow(convId: String): Flow<List<ChatMessage>> {
        return repository.getMessagesFlow(convId)
    }

    fun loadMessages(convId: String) {
        viewModelScope.launch {
            repository.loadMessagesForConversation(convId)
        }
    }

    fun clearNotice() {
        _uiState.value = _uiState.value.copy(lastSentDraftNotice = null)
    }

    // Native BLE Operations
    fun isBleSupported(): Boolean = bleManager.isBleSupported()
    fun isBluetoothEnabled(): Boolean = bleManager.isBluetoothEnabled()
    fun hasBlePermissions(): Boolean = bleManager.hasRequiredPermissions()
    fun onPermissionsDenied() = bleManager.onPermissionDenied()

    fun startBleAdvertising() {
        bleManager.startAdvertising()
    }

    fun stopBleAdvertising() {
        bleManager.stopAdvertising()
    }

    fun startBleScanning() {
        bleManager.startScanning()
    }

    fun stopBleScanning() {
        bleManager.stopScanning()
    }

    fun sendNativeBlePing(device: BluetoothDevice, text: String) {
        bleManager.sendDirectBleMessage(device, text)
    }

    fun disconnectBlePeer(address: String? = null) {
        bleManager.disconnectPeer(address)
    }

    fun selectBlePeer(peer: DiscoveredPeerDevice?) {
        _uiState.value = _uiState.value.copy(selectedBlePeer = peer)
    }

    fun refreshBleState() {
        bleManager.refreshHardwareState()
    }

    fun clearBleError() {
        bleManager.clearError()
    }

    override fun onCleared() {
        super.onCleared()
        bleManager.cleanup()
    }
}
